from django.db import models

#jobs model
class jobs(models.Model):
    name = models.CharField(max_length=100)
    address = models.CharField(max_length=100)
    email_ID= models.CharField(max_length=100)
    time_duration = models.CharField(max_length=100)
    city= models.CharField(max_length=100)
    type_job = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=100)
    job_desc = models.TextField()
    

