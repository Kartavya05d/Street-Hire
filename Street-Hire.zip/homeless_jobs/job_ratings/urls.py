from django.urls import path
from . import views
urlpatterns = [
    path('', views.home, name='job_ratings-home'), #this maps onto job home view 
    path('After_Submit/', views.After_Submit, name='job_ratings-After_Submit'), #after clicking submit
    path('add_job/', views.add_job, name='job_ratings-add_job') #the add jobs page 
   
]   