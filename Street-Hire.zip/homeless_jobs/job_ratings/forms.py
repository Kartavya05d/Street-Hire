from django import forms 
from django.forms import ModelForm
from .models import jobs

# Create a job form
class JobForm(ModelForm):
    class Meta:
        model = jobs
        fields = ('name', 'address', 'email_ID', 'time_duration', 'city', 'type_job', 'phone_number', 'job_desc')
        #just uses placeholders as fields
        labels = {
            'name': '',
            'address': '',
            'email_ID': '',
            'time_duration': '',
            'city': '',
            'type_job': '',
            'phone_number': '',
            'job_desc':  '',

        }
        widgets = {
            'name':forms.TextInput(attrs={'class':'form-control', 'placeholder':'Full Name'}),
            'address':forms.TextInput(attrs={'class':'form-control','placeholder':'Address'}),
            'email_ID':forms.EmailInput(attrs={'class':'form-control', 'placeholder':'Email ID'}),
            'time_duration':forms.TextInput(attrs={'class':'form-control','placeholder':'Time Duration'}),
            'city':forms.TextInput(attrs={'class':'form-control','placeholder':'Current City'}),
            'type_job':forms.TextInput(attrs={'class':'form-control','placeholder':'Type of Job'}),
            'phone_number':forms.TextInput(attrs={'class':'form-control', 'placeholder':'Phone Number'}),
            'job_desc':forms.TextInput(attrs={'class':'form-control', 'placeholder':'Job Description'}),

        }