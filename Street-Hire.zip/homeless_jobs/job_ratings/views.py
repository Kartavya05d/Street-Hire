from django.shortcuts import render
from .models import jobs
from .forms import JobForm
from django.http import HttpResponseRedirect
# Create your views here.

# home page
def home(request):
    return render(request, 'job_ratings/home.html') #renders the html template

# add jobs page 
def add_job(request):
    submitted = False
    if request.method == "POST":
        form = JobForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/After_Submit?submitted=True') #redirects to after submit if submission is valid
    else:
        form = JobForm
        if 'submitted' in request.GET:
            submitted = True

    return render(request, 'job_ratings/add_job.html', {'form':form, 'submitted':submitted})

#after submit page
def After_Submit(request):
    
    return render(request,'job_ratings/After_Submit.html' )

#this is the database we could connect to somewhere in the future!
def database(request):
    context = {
        'jobs': jobs.objects.all() #imports the jobs data to store in database we can make in future!
      
    }
    return render(request, 'job_ratings/database.html', context)